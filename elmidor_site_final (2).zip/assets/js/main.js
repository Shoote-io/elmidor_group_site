// Elmidor Group - main.js (v2)
document.addEventListener('DOMContentLoaded', ()=>{
  const menuBtn = document.getElementById('menuBtn');
  const navLinks = document.getElementById('navLinks');
  menuBtn?.addEventListener('click', ()=>{
    const isOpen = navLinks.getAttribute('data-open') === 'true';
    navLinks.setAttribute('data-open', String(!isOpen));
    menuBtn.setAttribute('aria-expanded', String(!isOpen));
  });
  const y = document.getElementById('year'); if(y) y.textContent = new Date().getFullYear();
});
